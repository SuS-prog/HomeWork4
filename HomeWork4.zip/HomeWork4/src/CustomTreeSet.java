import java.util.Objects;
import java.util.HashSet;
import java.util.TreeMap;
import java.util.TreeSet;
public class CustomTreeSet<E> {
    CustomTreeMap<E, Object> map = new CustomTreeMap<>();
    public static Object PRESENT = new Object();
    public boolean add(E e){
        return map.put(e, PRESENT) == null;
    }
    public boolean remove(E e){
        return map.remove(e) == PRESENT;
    }
    public boolean contains(Object o){
        return !(map.findNode(o) == null);
    }
    public int size(){
        return map.size();
    }
}
