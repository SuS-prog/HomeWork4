import java.util.TreeSet;

public class Main {
    public static void main(String[] args) {
        TreeSet<String> map = new TreeSet<>();
        map.add("One");
        map.add("Two");
        map.add("Three");
        System.out.println(map.add("Two"));
        System.out.println(map.add("Four"));
        System.out.println(map.size());
        System.out.println(map.contains("Two"));
        System.out.println(map.remove("Two"));
        System.out.println(map.contains("Two"));
    }
}
